from django.shortcuts import render
from .models import *
from .form import *

# Create your views here.

def index(request):
    form=mediaform()
    if request.method == 'POST':
        form=mediaform(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            return lists(request)
    return render (request,'index.html',{'f':form})


def lists(request):
    p=Media.objects.all()
    return render (request,'list.html',{'c':p})

def deletey(request,p):
    a=Media.objects.get(pk=p)
    a.delete()
    return lists(request)