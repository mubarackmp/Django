from .models import *
from django import forms


class mediaform(forms.ModelForm):
    class Meta:
        model=Media
        fields='__all__'