from django.db import models

# Create your models here.

class Media(models.Model):
    name=models.CharField(max_length=25)
    rollno=models.IntegerField()
    place=models.CharField(max_length=25)
    photo=models.ImageField(upload_to='book/cover',null=True,blank=True)
    cv=models.FileField(upload_to='book/pdf')