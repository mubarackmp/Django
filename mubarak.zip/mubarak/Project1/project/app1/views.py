from django.shortcuts import render
from .models import *
from .form import *
from .form1 import *
# Create your views here.

def base(request):
    return render(request,'base.html')

def ad(request):
    d=tableform()
    if request.method=='POST':
        d=tableform(request.POST)
        if d.is_valid():
            d.save()
            return lis(request)
    return render(request,'add.html',{'f':d})

def edit(request,p):
    a=tablename.objects.get(pk=p)
    b=tableform(instance=a)
    if request.method=='POST':
        b=tableform(request.POST,instance=a)
        if b.is_valid():
            b.save()
            return lis(request)
    return render(request,'edit.html',{'f':b})

def dele(request,p):
    a=tablename.objects.get(pk=p)
    a.delete()
    return lis(request)

def home(request):
    return render(request,'home.html')

def lis(request):
    p=tablename.objects.all()
    return render(request,'list.html',{'d':p})
