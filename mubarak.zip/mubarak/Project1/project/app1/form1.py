from django import forms
from .models import *

class tableform1(forms.ModelForm):
    class Meta:
        model=tablename
        fields=('name','rollno')