from django import forms
from .models import *

class tableform(forms.ModelForm):
    class Meta:
        model=tablename
        fields='__all__'
