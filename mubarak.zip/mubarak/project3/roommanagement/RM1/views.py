from django.shortcuts import render
from .models import *
from .form import *

# Create your views here.
def add(request):
    a=RoomForm()
    if request.method == 'POST':
        a=RoomForm(request.POST)
        if a.is_valid():
            a.save()
            return list1(request)
    return render(request,'add.html',{'form':a})

    
def list1(request):
    p1=Rooms.objects.all()
    return render(request,'list1.html',{'c':p1})

def list2(request):
    p2=BookedRooms.objects.all()
    return render(request,'list2.html',{'d':p2})

def ckeckin(request,p):
    a=Rooms.objects.get(pk=p)
    b=BookedRoomForm(instance=a)
    if b.is_valid():
        b.save()
    a.delete()
    return list2(request)

def ckeckout(request,q):
    a=BookedRooms.objects.get(pk=q)
    b=RoomForm(instance=a)
    b=RoomForm(request.POST,instance=a)
    if b.is_valid():
        b.save()
    a.delete()
    return list1(request)