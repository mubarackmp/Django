from django.db import models

# Create your models here.

class Rooms(models.Model):
    no=models.IntegerField()
    typee=models.CharField(max_length=10)
    count=models.IntegerField()

class BookedRooms(models.Model):
    no=models.IntegerField()
    typee=models.CharField(max_length=10)
    count=models.IntegerField()